package uk.ac.shef.dcs.jate.feature;

/**
 * Created by zqz on 16/09/2015.
 */
public class AbstractFeature {
}
