package org.apache.lucene.analysis.jate;

/**
 * Created by - on 14/10/2015.
 */
public interface MWESentenceAware {
}
