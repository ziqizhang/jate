package org.apache.lucene.analysis.jate;

/**
 *
 */
public interface OriginTrackable {


}
